﻿namespace inventory_login
{
    partial class reporting_viewr
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Microsoft.Reporting.WinForms.ReportDataSource reportDataSource2 = new Microsoft.Reporting.WinForms.ReportDataSource();
            this.reportViewer1 = new Microsoft.Reporting.WinForms.ReportViewer();
            this.inventoy_loginDataSet = new inventory_login.inventoy_loginDataSet();
            this.StockBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.StockTableAdapter = new inventory_login.inventoy_loginDataSetTableAdapters.StockTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.inventoy_loginDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // reportViewer1
            // 
            this.reportViewer1.Dock = System.Windows.Forms.DockStyle.Fill;
            reportDataSource2.Name = "DataSet1";
            reportDataSource2.Value = this.StockBindingSource;
            this.reportViewer1.LocalReport.DataSources.Add(reportDataSource2);
            this.reportViewer1.LocalReport.ReportEmbeddedResource = "inventory_login.Report1.rdlc";
            this.reportViewer1.Location = new System.Drawing.Point(0, 0);
            this.reportViewer1.Name = "reportViewer1";
            this.reportViewer1.Size = new System.Drawing.Size(497, 261);
            this.reportViewer1.TabIndex = 0;
            // 
            // inventoy_loginDataSet
            // 
            this.inventoy_loginDataSet.DataSetName = "inventoy_loginDataSet";
            this.inventoy_loginDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // StockBindingSource
            // 
            this.StockBindingSource.DataMember = "Stock";
            this.StockBindingSource.DataSource = this.inventoy_loginDataSet;
            // 
            // StockTableAdapter
            // 
            this.StockTableAdapter.ClearBeforeFill = true;
            // 
            // reporting_viewr
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(497, 261);
            this.Controls.Add(this.reportViewer1);
            this.Name = "reporting_viewr";
            this.Text = "reporting_viewr";
            this.Load += new System.EventHandler(this.reporting_viewr_Load);
            ((System.ComponentModel.ISupportInitialize)(this.inventoy_loginDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.StockBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private Microsoft.Reporting.WinForms.ReportViewer reportViewer1;
        private System.Windows.Forms.BindingSource StockBindingSource;
        private inventoy_loginDataSet inventoy_loginDataSet;
        private inventoy_loginDataSetTableAdapters.StockTableAdapter StockTableAdapter;
    }
}