﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_login
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True";

            DataSet ds = new DataSet();
            string query = "select * from Reg_admin ";


            SqlDataAdapter regadapter = new SqlDataAdapter(query, conn);
            SqlCommandBuilder buil = new SqlCommandBuilder(regadapter);

            regadapter.Fill(ds, "Reg_admin");

            DataRow dr = ds.Tables["Reg_admin"].NewRow();
            dr["Company_id"] = txt_id.Text;
            dr["f_name"] = txt_name.Text;
            dr["Pass"] = txt_pass.Text;
            dr["C_pass"] = txt_pass1.Text;
            dr["cnic"] = maskedTextBox1.Text;


            ds.Tables["Reg_admin"].Rows.Add(dr);
            
            regadapter.Update(ds, "Reg_admin");
            




            //Admin_login table insertion
            DataSet ds2 = new DataSet();
            string query2 = "select * from Admin_login ";


            SqlDataAdapter regadapter2 = new SqlDataAdapter(query2, conn);
            SqlCommandBuilder buil2 = new SqlCommandBuilder(regadapter2);

            regadapter2.Fill(ds2, "Admin_login");

            DataRow dr2 = ds2.Tables["Admin_login"].NewRow();
            dr2["uName"] = txt_name.Text;
            dr2["Pass"] = txt_pass.Text;

            ds2.Tables["Admin_login"].Rows.Add(dr2);

            regadapter2.Update(ds2, "Admin_login");
            


            
            
            MessageBox.Show("record succsessfully insert");

            Form1.ActiveForm.Show();


        }
    }
}
