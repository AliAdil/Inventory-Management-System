﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_login
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private bool IsvalidUser(string userName, string password)
        {



            DataClasses1DataContext context = new DataClasses1DataContext();

            var q = from p in context.Admin_logins

                    where p.uName == txt_name.Text
                    
                    && p.Pass == txt_pass.Text

                    select p;



            if (q.Any())
            {

                return true;

            }

            else
            {

                return false;

            }

        }
        private void Login_Click(object sender, EventArgs e)
        {


            if (IsvalidUser(txt_name.Text, txt_pass.Text))
            {
                MessageBox.Show("login sussessfully!");
                main1 mn = new main1();
                mn.Show();

            }
            else {
                MessageBox.Show("Err!");
            }


        }

        private void Createuser_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 form = new Form2();
            form.Show();


        }
    }
}
