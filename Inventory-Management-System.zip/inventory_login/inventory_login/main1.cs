﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_login
{
    public partial class main1 : Form
    {
        
        public main1()
        {
            InitializeComponent();
        }
        

        private void main1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'inventoy_loginDataSet.Stock' table. You can move, or remove it, as needed.
            this.stockTableAdapter.Fill(this.inventoy_loginDataSet.Stock);
            updateGrid();
            
            
            Insert obj = (Insert)Application.OpenForms["Insert"];

            
            dataGridView1.Update();
            dataGridView1.Refresh();


        }

        private void updateGrid()
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True";

            DataSet ds = new DataSet();
            string query = "select * from Stock ";

            SqlDataAdapter stkadapter = new SqlDataAdapter(query, conn);
            stkadapter.Fill(ds, "Stock");
            dataGridView1.DataSource = ds.Tables["Stock"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
           Insert ins = new Insert();
           ins.Show();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "Product ID")
            {
                SqlConnection conn = new SqlConnection("Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True");
                // string q = "Select * from Stock Where Product_id like '" + txtBox1.Text + "'";
                SqlDataAdapter ad = new SqlDataAdapter("Select * from Stock Where Product_id like '" + txtBox1.Text + "'", conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            }

            if(comboBox1.Text == "Product Name")
            {
            SqlConnection conn = new SqlConnection("Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True");
                // string q = "Select * from Stock Where Product_id like '" + txtBox1.Text + "'";
                SqlDataAdapter ad = new SqlDataAdapter("Select * from Stock Where P_name like '" + txtBox1.Text + "'", conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;
            
            }

            if (comboBox1.Text == "Quantity")
            {
                SqlConnection conn = new SqlConnection("Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True");
                // string q = "Select * from Stock Where Product_id like '" + txtBox1.Text + "'";
                SqlDataAdapter ad = new SqlDataAdapter("Select * from Stock Where P_quantity like '" + txtBox1.Text + "'", conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;

            }

            if (comboBox1.Text == "Price")
            {
                SqlConnection conn = new SqlConnection("Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True");
                // string q = "Select * from Stock Where Product_id like '" + txtBox1.Text + "'";
                SqlDataAdapter ad = new SqlDataAdapter("Select * from Stock Where P_price like '" + txtBox1.Text + "'", conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;

            }

            if (comboBox1.Text == "Purchasing Date")
            {
                SqlConnection conn = new SqlConnection("Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True");
                // string q = "Select * from Stock Where Product_id like '" + txtBox1.Text + "'";
                SqlDataAdapter ad = new SqlDataAdapter("Select * from Stock Where P_purchasing_date like '" + txtBox1.Text + "'", conn);
                DataTable dt = new DataTable();
                ad.Fill(dt);
                dataGridView1.DataSource = dt;

            }


            
            }

        private void button2_Click(object sender, EventArgs e)
        {
        
        }

        private void button3_Click(object sender, EventArgs e)
        {
            reporting_viewr rep = new reporting_viewr();
            rep.Show();

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            
        }

        private void Exit_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

            
 
        }
        
        
}
