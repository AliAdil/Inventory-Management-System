﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace inventory_login
{
    public partial class Insert : Form
    {
        public Insert()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void MainForm_Load(object sender, EventArgs e)
        {

        
        }
        
        
        private void button1_Click(object sender, EventArgs e)
        {
            SqlConnection conn = new SqlConnection();
            conn.ConnectionString = "Data Source=SOHAIB\\SQLEXPRESS;Initial Catalog=inventoy_login;Integrated Security=True";

            DataSet ds = new DataSet();
            string query = "select * from Stock ";

            SqlDataAdapter stkadapter = new SqlDataAdapter(query, conn);
            SqlCommandBuilder stkbuil = new SqlCommandBuilder(stkadapter);

            stkadapter.Fill(ds, "Stock");
            DataRow dr = ds.Tables["Stock"].NewRow();

            dr["Product_id"] = txt_pid.Text;
            dr["P_name"] = txt_Pname.Text;
            dr["P_quantity"] = txt_Quan.Text;
            dr["P_price"] = txt_price.Text;
            dr["P_purchasing_date"] = dateTimePicker1.Text;
            dr["P_category"] = txt_cate.Text;
            dr["P_location"] = txt_location.Text;
            dr["P_Total"] = txt_total.Text;

            ds.Tables["Stock"].Rows.Add(dr);
            stkadapter.Update(ds, "Stock");
            txt_cate.Text = txt_location.Text = txt_pid.Text = txt_Pname.Text = txt_price.Text = txt_Quan.Text = "";

            MessageBox.Show("Record entered sucsessfully");
            this.Hide();
            
        }
        
        
        private void txt_price_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void txt_price_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void txt_Quan_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
            }
        }

        private void txt_pid_KeyPress(object sender, KeyPressEventArgs e)
        {
            char ch = e.KeyChar;

            if (!char.IsDigit(ch) && ch != 8)
            {
                e.Handled = true;
                

            }
        }

       
        private void txt_total_TextChanged(object sender, EventArgs e)
        {
            
            
            
        }

        private void txt_pid_TextChanged(object sender, EventArgs e)
        {
            
        }
    }
}
