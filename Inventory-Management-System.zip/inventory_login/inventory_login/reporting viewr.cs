﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace inventory_login
{
    public partial class reporting_viewr : Form
    {
        public reporting_viewr()
        {
            InitializeComponent();
        }

        private void reporting_viewr_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'inventoy_loginDataSet.Stock' table. You can move, or remove it, as needed.
            this.StockTableAdapter.Fill(this.inventoy_loginDataSet.Stock);

            this.reportViewer1.RefreshReport();
        }
    }
}
